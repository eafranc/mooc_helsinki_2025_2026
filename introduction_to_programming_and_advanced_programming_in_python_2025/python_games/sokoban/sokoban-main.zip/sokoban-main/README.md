# sokoban
Pythonilla toteutettu Sokoban-peli Ohjelmoinnin jatkokurssille
